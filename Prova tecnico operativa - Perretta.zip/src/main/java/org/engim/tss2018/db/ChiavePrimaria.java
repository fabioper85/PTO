package org.engim.tss2018.db;

public interface ChiavePrimaria 
{
  Integer getId();
}
